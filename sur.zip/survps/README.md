## SurVPS

```bash
bash <(curl -s https://f97.xyz/survps/install)
```
